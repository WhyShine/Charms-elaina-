

export const dada = (prefix, pushname, ucapanWaktu) => {
return `${ucapanWaktu} kak ${pushname}
Untuk memasukan bot ke dalam group
kamu harus menyewa bot terlebih dahulu
harga mulai 3k untuk 7 hari.


untuk order
silakan hub: wa.me/6282353035070
`
}





















